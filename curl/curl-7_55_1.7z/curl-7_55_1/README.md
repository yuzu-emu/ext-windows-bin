Built from curl git tag curl-7_55_1 This build links curl against windows sspi (native TLS) instead of openssl making it more portable for windows users

Generated with the following process

./configure.bat
mingw32-make.exe mingw32-sspi
