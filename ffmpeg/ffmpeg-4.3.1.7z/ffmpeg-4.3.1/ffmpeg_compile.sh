#!/bin/bash

# Script is to be run from ffmpeg base directory.
# This script compiles and creates a package for the FFmpeg version specified in VERSION.
# Compilation target is x86_64 mingw32

set -e

THIS=$(readlink -e $0)
VERSION=4.3.1
INSTALL_DIR=ffmpeg-${VERSION}

git checkout n${VERSION}
mkdir build || true
cd build
../configure --arch=x86_64 --target-os=mingw32 --cross-prefix=x86_64-w64-mingw32- --disable-avdevice --disable-avfilter --disable-avformat --disable-doc --disable-everything --disable-ffmpeg --disable-ffprobe --disable-network --disable-postproc --disable-swresample --disable-vaapi --disable-vdpau --enable-decoder=h264 --enable-decoder=vp9 --enable-shared --disable-w32threads --prefix=/
make -j$(nproc)

mkdir ${INSTALL_DIR}
cp ${THIS} ${INSTALL_DIR}
make install DESTDIR=${INSTALL_DIR}
7z a ${INSTALL_DIR}.7z ${INSTALL_DIR}